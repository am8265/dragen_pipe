use strict;
use Math::Base36;
use Data::Dumper;
my$i=$ARGV[0];
$i||die;
open(my$ih,'<',$i)||die;
while(my$l=<$ih>){
    chomp($l);
    my@l=split("\t",$l);
    my$max='a';
    next if($l[2]!~/[c-g]/);
    my@ll=split(/([a-g]+)/,$l[2]);
    my$LAST_A_B=0;
    my@LAST_A_B;
    my$NEW=q{};
    for my$i (0..(scalar(@ll)>>1)-1){
        my$g=$i;
        $i*=2;
        my$ii=$i+1;
        if($ll[$i+1] eq 'a'||$ll[$i+1] eq 'b') {
            $LAST_A_B=1; 
            push(@LAST_A_B,[$ll[$i],$ll[$i+1]]);
        }else{
            if($LAST_A_B) {
                my$s=0;
                for my$L (@LAST_A_B) { $s+=Math::Base36::decode_base36($L->[0],10); }
                $NEW.=Math::Base36::encode_base36($s).'b';
            }
            $NEW.=$ll[$i].$ll[$i+1];
            $LAST_A_B=0; 
            undef(@LAST_A_B);
        }
    }
    if($LAST_A_B) {
        my$s=0;
        for my$L (@LAST_A_B) { $s+=Math::Base36::decode_base36($L->[0],10); }
        $NEW.=Math::Base36::encode_base36($s).'b';
    }
    print qq{$l[0]\t$l[1]\t$NEW\n}; # \tORIG=$l[2]\n};
}

